package Exercises.List_8.Task_2;

// square, rectangle, triangle, circle
public interface IShape {
    double getArea();
}